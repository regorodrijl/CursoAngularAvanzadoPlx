# b - PWA: Entre la web y las apps con Angular

## b.1 Configurtación
npm install http-server -g
ng add @angular/pwa
npm install -g ngx-pwa-icons

## b.2 Uso de servicios
src\app\core\navigator\navigator.component.ts

## b.3 Cache
ngsw-config.json
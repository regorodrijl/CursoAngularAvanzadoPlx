# Práctica de Angular Avanzado

## Buscar y filtrar lanzamientos de cohetes espaciales

- [API Launch Library](http://launchlibrary.net/docs/1.4/api.html#launch)
- Filtrar por texto o entre fechas.
- Acotar el número de resultados elegido por el usuario
- Mostrar listado con nombre y enlace a página detalle
- Página de detalle mostrando nombre y fechas clave.

# 1 - detector 
## 1.1 Default
## 1.2 OnPush

# 2 - family
## 2.1 Default/Default
## 2.2 Onpush/Default
## 2.3 Default/Onpush
## 2.4 Onpush/Onpush


# 3 - subscribe 
## 3.1 Default
## 3.2 OnPush

# 4 - async 
## 4.1 Default
## 4.2 OnPush

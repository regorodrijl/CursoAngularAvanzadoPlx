export const environment = {
  production: true,
  apiUrl: 'https://api-base.herokuapp.com/api/',
  assetsUrl: './assets/'
};

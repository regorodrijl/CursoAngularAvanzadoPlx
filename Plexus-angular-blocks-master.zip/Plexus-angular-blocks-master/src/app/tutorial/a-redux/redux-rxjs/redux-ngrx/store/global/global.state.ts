export interface GlobalState {
  message: string;
}

export const GLOBAL_INITIAL_STATE: GlobalState = {
  message: ''
};

export class CounterState {
  value: number;
}

export const INITIAL_COUNTER_STATE: CounterState = { value: 0 };

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-container',
  templateUrl: './change-container.component.html',
  styles: []
})
export class ChangeContainerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-info',
  templateUrl: './about-info.component.html',
  styles: []
})
export class AboutInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shell-main',
  templateUrl: './shell-main.component.html',
  styles: []
})
export class ShellMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
